plugins { id("com.android.application") }

android {
    namespace = "com.voltride.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.voltride.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
