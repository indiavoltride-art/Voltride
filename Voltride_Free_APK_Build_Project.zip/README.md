# Voltride — free APK build project

This package wraps the supplied Voltride HTML app in a simple Android WebView.

Build on GitHub Actions:
1. Create a GitHub repository.
2. Upload all files/folders from this project.
3. Open Actions -> Build Voltride APK -> Run workflow.
4. Download the `voltride-debug-apk` artifact.

Note: the supplied HTML currently uses demo OTP and a demo map; it is not connected to real Firebase OTP, payments, live GPS, or a backend.
